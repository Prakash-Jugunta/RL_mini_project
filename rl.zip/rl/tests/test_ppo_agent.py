"""
Unit tests for PPO Agent (rl.agents.ppo).
"""

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import tempfile
import numpy as np
import pytest
import torch

from rl.agents.ppo import PPOAgent, PPOConfig, save_checkpoint, load_checkpoint


def create_mock_obs():
    return {
        "objective": np.random.randn(64).astype(np.float32),
        "context": np.random.randn(30).astype(np.float32),
        "candidates": np.random.randn(20, 91).astype(np.float32),
        "candidate_mask": np.array([1.0]*5 + [0.0]*15, dtype=np.float32),
    }


def test_ppo_action_selection_and_validity():
    agent = PPOAgent()
    obs = create_mock_obs()

    # Eval mode greedy selection
    act_eval, val_eval, logp_eval = agent.select_action(obs, eval_mode=True)
    assert 0 <= act_eval < 5  # Must be valid candidate slot
    assert isinstance(val_eval, float)
    assert isinstance(logp_eval, float)

    # Stochastic training selection
    act_train, val_train, logp_train = agent.select_action(obs, eval_mode=False)
    assert 0 <= act_train < 5


def test_ppo_update_and_weight_change():
    config = PPOConfig(rollout_steps=16, minibatch_size=8, update_epochs=2)
    agent = PPOAgent(config)

    initial_weights = [p.clone().detach() for p in agent.network.parameters()]

    for _ in range(16):
        obs = create_mock_obs()
        act, val, logp = agent.select_action(obs, eval_mode=False)
        agent.rollout_buffer.add(obs, act, reward=1.0, value=val, log_prob=logp, done=False, truncated=False)

    diag = agent.update(last_value=0.5, last_done=True)
    assert "policy_loss" in diag
    assert "value_loss" in diag
    assert "entropy" in diag

    updated_weights = [p for p in agent.network.parameters()]
    weights_changed = any(not torch.equal(w0, w1) for w0, w1 in zip(initial_weights, updated_weights))
    assert weights_changed


def test_ppo_checkpoint_roundtrip():
    agent = PPOAgent()
    obs = create_mock_obs()
    act, val, logp = agent.select_action(obs)

    with tempfile.TemporaryDirectory() as tmp_dir:
        chk_path = os.path.join(tmp_dir, "ppo_ckpt.pt")
        save_checkpoint(chk_path, agent, extra_info={"custom_field": 42})

        new_agent = PPOAgent()
        meta = load_checkpoint(chk_path, new_agent)

        assert meta["custom_field"] == 42
        for p0, p1 in zip(agent.network.parameters(), new_agent.network.parameters()):
            assert torch.equal(p0, p1)


def test_ppo_no_private_metadata_in_rollout():
    """Verify rollout buffer stores only public observation fields."""
    agent = PPOAgent()
    obs = create_mock_obs()
    agent.rollout_buffer.add(obs, action=0, reward=1.0, value=0.5, log_prob=-1.0, done=False)

    assert hasattr(agent.rollout_buffer, "objectives")
    assert hasattr(agent.rollout_buffer, "contexts")
    assert hasattr(agent.rollout_buffer, "candidates")
    assert hasattr(agent.rollout_buffer, "candidate_masks")

    assert not hasattr(agent.rollout_buffer, "semantic_role")
    assert not hasattr(agent.rollout_buffer, "ground_truth")
